
N=1000 
x = runif(N,0,1)
sigma=2; # Noise
noise = rnorm(N,0,sigma)
alpha = 4
beta=5
y = alpha + beta*x + noise
y_gold=alpha + beta*x 

plot (x,y_gold)
plot(x,y)

library("rstan") 
setwd("C:\\Users\\ygeorge\\Desktop\\SML 17\\Wokrshop#11")


fit <- stan(file = 'linear_regression.stan', data = list("N", "x", "y"), iter = 1000, chains = 4);
print(fit)
plot(fit)


pairs(fit) #, pars = c("mu", "tau", "lp__"))

#install.packages("rstan", type="source")
#install.packages("rstan")
#source('http://mc-stan.org/rstan/install.R', echo = TRUE, max.deparse.length = 2000) install_rstan()
# TRY THIS
#install.packages("rstan", repos = "https://cloud.r-project.org/", dependencies=TRUE)

#OR THIS
#Sys.setenv(MAKEFLAGS = "-j4") 
#install.packages("rstan", type = "source")