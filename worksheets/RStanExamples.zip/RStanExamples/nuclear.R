library("rstan")
#setwd("path of stan files")


# Read Nuclear Data
Nuclear_Data = read.delim("nuclear.txt", skip = 1,sep=",",header = 0) 
# fit <- stan(file = 'nuclear.stan', data = Nuclear_Data, iter = 100, chains = 1)
#schools_dat <- list(J = 8, y = c(28,  8, -3,  7, -1,  1, 18, 12), sigma = c(15, 10, 16, 11,  9, 11, 10, 18))

# Convert Logicals to Numerical values ( 0,1)
Numeric_Data = as.numeric(Nuclear_Data == "true")
Observation_Table <- matrix(Numeric_Data, nrow = 10000, byrow = FALSE)

#DATA Initilization
HT=Observation_Table[,1]
FA=Observation_Table[,2]
FG=Observation_Table[,3]
HG=Observation_Table[,4]
AS=Observation_Table[,5]
ALPHA=1
BETA=1

#Modelling
Nuclear_DAT<- list(N =10000, HT,FG,FA,HG,AS,ALPHA,BETA);
fit = stan(file = 'nuclear.stan', data = Nuclear_DAT, iter = 100, chains = 1)

plot(fit)
traceplot(fit)
summary(fit)
fit
dim(fit)
dimnames(fit)

la = extract(fit, permuted = TRUE) # return a list of arrays 
